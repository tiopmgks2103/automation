require_relative '../support/local_driver'

LocalDriver.start_driver
