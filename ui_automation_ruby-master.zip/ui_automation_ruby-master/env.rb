dir = Dir.pwd
$webdriver = dir + '/assets/driver/chrome/chromedriver'

ENV['PROJECT_DIR'] = dir
ENV['URL'] = ''